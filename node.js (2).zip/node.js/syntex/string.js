console.log('1' + '2');
console.log('안녕하세요');
console.log('노드.js 무서워용');

console.log('안녕dfkjhsdgkns;dkgnwpeognewpong'.length)