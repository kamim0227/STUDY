var name1  = 'k880'
var letter = '안녕dfk'+name1+'jhsdgkns;dkgnwpeognewpong'
console.log(letter);