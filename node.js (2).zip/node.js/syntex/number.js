console.log(1+1);
console.log(4-3);
console.log(4*1);
console.log(1/4);




