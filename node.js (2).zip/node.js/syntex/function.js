function f123(){
  console.log(1);
  console.log(2);
  console.log(3);
  console.log(4);
}

f123();

console.log("===========");

console.log(Math.round(16.77));//반올림함수
console.log(Math.round(1.4));//반올림함수

function sum(num1, num2){
  return num1+ num2;
}

console.log(sum(7,8));