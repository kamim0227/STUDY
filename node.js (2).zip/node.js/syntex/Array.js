//CRUD
var arr = ['A','B','C','D','E'];

console.log(arr[1])
console.log(arr[3])

console.log(arr[2])
arr[2] = 7;
console.log(arr[2])

// 배열개수
console.log(arr.length)

console.log(arr)
arr.push('77');
console.log(arr)