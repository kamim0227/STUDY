//String , Number
// Boolean > True, False



console.log(1==1);// true
console.log(1==2);// false
console.log(1>2);// false
console.log(1<2);// true

// = > 대입 연산자
//== 비교 연산자 (값만 비교 , 형태비교 안함)
// === 비교 연산자 (값과 형태가 둘다 동일해야 true 반환)


