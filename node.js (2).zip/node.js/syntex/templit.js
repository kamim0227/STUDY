var name1  = 'k880'
var letter = `안녕dfk${name1}
${1+1}
jhsdgkns${444+777};dkgnwpeognewpong`
console.log(letter);

//템플릿리터럴 
//리터럴 : 정보를 표현하는 기호
