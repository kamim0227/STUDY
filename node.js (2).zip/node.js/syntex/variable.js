var a = 1;
console.log(a);
a = 3;
console.log(a);
