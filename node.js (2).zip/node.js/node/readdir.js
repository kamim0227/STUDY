var testFolder = 'node';
var fs = require('fs');

fs.readdir(testFolder, function(err, filelist){
    console.log(filelist)
    //특정디렉토리의 리스트를 배열로 생성해 반환한다
});
